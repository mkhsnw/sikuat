<?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md bg-white shadow-md rounded-lg p-8 mx-auto mt-6">
        <?php if(session('error')): ?>
            <div class="bg-red-50 border border-red-500 text-red-900 px-4 py-3 rounded relative mb-4" role="alert">
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Verifikasi OTP</h2>
            <p class="text-gray-600 mt-2">Masukkan kode OTP yang telah dikirimkan</p>
        </div>

        <form method="POST" action="<?php echo e(route('token.verify')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="email" value="<?php echo e(old('email', session('email'))); ?>">
            
            <div>
                <label for="token" class="block mb-2 text-sm font-medium text-gray-700 text-center">
                    Masukkan OTP
                </label>
                <?php if (isset($component)) { $__componentOriginalcd8ef4011feb8d1586574d96bc7aa055 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd8ef4011feb8d1586574d96bc7aa055 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.code','data' => ['name' => 'token','errorMessage' => 'Yoh! check your code','onVerify' => 'checkPinShowError','class' => 'w-full','totalDigits' => '5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'token','error_message' => 'Yoh! check your code','on_verify' => 'checkPinShowError','class' => 'w-full','total_digits' => '5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd8ef4011feb8d1586574d96bc7aa055)): ?>
<?php $attributes = $__attributesOriginalcd8ef4011feb8d1586574d96bc7aa055; ?>
<?php unset($__attributesOriginalcd8ef4011feb8d1586574d96bc7aa055); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd8ef4011feb8d1586574d96bc7aa055)): ?>
<?php $component = $__componentOriginalcd8ef4011feb8d1586574d96bc7aa055; ?>
<?php unset($__componentOriginalcd8ef4011feb8d1586574d96bc7aa055); ?>
<?php endif; ?>
            </div>

            <button 
                type="submit" 
                class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
            >
                Verifikasi
            </button>
        </form>
    </div>
</body><?php /**PATH C:\laragon\www\sikuat\resources\views/auth/input-token.blade.php ENDPATH**/ ?>