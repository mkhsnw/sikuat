<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => config('bladewind.table.striped', false),
    // should the table with displayed with a drop-shadow effect
    'has_shadow' => config('bladewind.table.has_shadow', false),
    'hasShadow' => config('bladewind.table.has_shadow', false),
    // should the table have a border on all four sides
    'has_border' => config('bladewind.table.has_border', false),
    // should the table have row dividers
    'divided' => config('bladewind.table.divided', true),
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => config('bladewind.table.divider', 'regular'),
    // should rows light up on hover
    'hover_effect' => config('bladewind.table.hover_effect', true),
    'hoverEffect' => config('bladewind.table.hover_effect', true),
    // should the rows be tighter together
    'compact' => config('bladewind.table.compact', false),
    // provide a table name you can access via css
    'name' => 'tbl-'.uniqid(),
    'data' => null,
    'exclude_columns' => null,
    'include_columns' => null,
    'action_icons' => null,
    'groupby' => null,
    'actions_title' => 'actions',
    'column_aliases' => [],
    'searchable' => config('bladewind.table.searchable', false),
    'search_placeholder' => config('bladewind.table.search_placeholder', 'Search table below...'),
    'search_field' => null,
    'search_debounce' => 0,
    'search_min_length' => 0,
    'celled' => config('bladewind.table.celled', false),
    'uppercasing' => config('bladewind.table.uppercasing', true),
    'no_data_message' => config('bladewind.table.no_data_message', 'No records to display'),
    'message_as_empty_state' => config('bladewind.table.message_as_empty_state', false),
    // parameters expected by the empty state component ---------------
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '',
    'show_image' => config('bladewind.table.show_image', true),
    'onclick' => '',
    //------------------ end empty state parameters -------------------
    'selectable' => config('bladewind.table.selectable', false),
    'checkable' => config('bladewind.table.checkable', false),
    'transparent' => config('bladewind.table.transparent', false),
    'selected_value' => null,
    'sortable' => config('bladewind.table.sortable', false),
    'sortable_columns' => [],
    'paginated' => config('bladewind.table.paginated', false),
    'pagination_style' => config('bladewind.table.pagination_style', 'arrows'),
    'page_size' => config('bladewind.table.page_size', 25),
    'show_row_numbers' => config('bladewind.table.show_row_numbers', false),
    'show_total' => config('bladewind.table.show_total', true),
    'show_page_number' => config('bladewind.table.show_page_number', true),
    'show_total_pages' => config('bladewind.table.show_total_pages', false),
    'default_page' => 1,
    'total_label' => config('bladewind.table.total_label', 'Showing :a to :b of :c records'),
    'limit' => null,
    'layout' => 'auto',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => config('bladewind.table.striped', false),
    // should the table with displayed with a drop-shadow effect
    'has_shadow' => config('bladewind.table.has_shadow', false),
    'hasShadow' => config('bladewind.table.has_shadow', false),
    // should the table have a border on all four sides
    'has_border' => config('bladewind.table.has_border', false),
    // should the table have row dividers
    'divided' => config('bladewind.table.divided', true),
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => config('bladewind.table.divider', 'regular'),
    // should rows light up on hover
    'hover_effect' => config('bladewind.table.hover_effect', true),
    'hoverEffect' => config('bladewind.table.hover_effect', true),
    // should the rows be tighter together
    'compact' => config('bladewind.table.compact', false),
    // provide a table name you can access via css
    'name' => 'tbl-'.uniqid(),
    'data' => null,
    'exclude_columns' => null,
    'include_columns' => null,
    'action_icons' => null,
    'groupby' => null,
    'actions_title' => 'actions',
    'column_aliases' => [],
    'searchable' => config('bladewind.table.searchable', false),
    'search_placeholder' => config('bladewind.table.search_placeholder', 'Search table below...'),
    'search_field' => null,
    'search_debounce' => 0,
    'search_min_length' => 0,
    'celled' => config('bladewind.table.celled', false),
    'uppercasing' => config('bladewind.table.uppercasing', true),
    'no_data_message' => config('bladewind.table.no_data_message', 'No records to display'),
    'message_as_empty_state' => config('bladewind.table.message_as_empty_state', false),
    // parameters expected by the empty state component ---------------
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '',
    'show_image' => config('bladewind.table.show_image', true),
    'onclick' => '',
    //------------------ end empty state parameters -------------------
    'selectable' => config('bladewind.table.selectable', false),
    'checkable' => config('bladewind.table.checkable', false),
    'transparent' => config('bladewind.table.transparent', false),
    'selected_value' => null,
    'sortable' => config('bladewind.table.sortable', false),
    'sortable_columns' => [],
    'paginated' => config('bladewind.table.paginated', false),
    'pagination_style' => config('bladewind.table.pagination_style', 'arrows'),
    'page_size' => config('bladewind.table.page_size', 25),
    'show_row_numbers' => config('bladewind.table.show_row_numbers', false),
    'show_total' => config('bladewind.table.show_total', true),
    'show_page_number' => config('bladewind.table.show_page_number', true),
    'show_total_pages' => config('bladewind.table.show_total_pages', false),
    'default_page' => 1,
    'total_label' => config('bladewind.table.total_label', 'Showing :a to :b of :c records'),
    'limit' => null,
    'layout' => 'auto',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $has_shadow = parseBladewindVariable($has_shadow);
    $hasShadow = parseBladewindVariable($hasShadow);
    $hover_effect = parseBladewindVariable($hover_effect);
    $hoverEffect = parseBladewindVariable($hoverEffect);
    $striped = parseBladewindVariable($striped);
    $compact = parseBladewindVariable($compact);
    $divided = parseBladewindVariable($divided);
    $searchable = parseBladewindVariable($searchable);
    $search_field = parseBladewindVariable($search_field, 'string');
    $search_debounce = parseBladewindVariable($search_debounce, 'int');
    $search_min_length = parseBladewindVariable($search_min_length, 'int');
    $uppercasing = parseBladewindVariable($uppercasing);
    $celled = parseBladewindVariable($celled);
    $selectable = parseBladewindVariable($selectable);
    $checkable = parseBladewindVariable($checkable);
    $transparent = parseBladewindVariable($transparent);
    $paginated = parseBladewindVariable($paginated);
    $sortable = parseBladewindVariable($sortable);
    $page_size = parseBladewindVariable($page_size, 'int');
    $message_as_empty_state = parseBladewindVariable($message_as_empty_state);
    $show_row_numbers = parseBladewindVariable($show_row_numbers);
    $show_total = parseBladewindVariable($show_total);
    $default_page = parseBladewindVariable($default_page, 'int');

    if ($hasShadow) $has_shadow = $hasShadow;
    if (!$hoverEffect) $hover_effect = $hoverEffect;
    $name = preg_replace('/[\s-]/', '_', $name);

    $exclude_columns = !empty($exclude_columns) ? explode(',', str_replace(' ','', $exclude_columns)) : [];
    $action_icons = (!empty($action_icons)) ? ((is_array($action_icons)) ?
        $action_icons : json_decode(str_replace('&quot;', '"', $action_icons), true)) : [];
    $column_aliases = (!empty($column_aliases)) ? ((is_array($column_aliases)) ?
        $column_aliases : json_decode(str_replace('&quot;', '"', $column_aliases), true)) : [];
    $icons_array = $indices = [];
    $can_group = false;

    if (!is_null($data)) {
        $data = (!is_array($data)) ? json_decode(str_replace('&quot;', '"', $data), true) : $data;

        $total_records = (!empty($limit)) ? $limit : count($data);
        $default_page = ($default_page > ceil($total_records/$page_size)) ? 1 : $default_page;
        $table_headings = $all_table_headings = ($total_records > 0) ? array_keys((array) $data[0]) : [];

        if( !empty($include_columns) ) {
            $exclude_columns = [];
            $table_headings = explode(',', str_replace(' ','', $include_columns));
        }

        if($sortable){
            $sortable_columns = empty($sortable_columns) ? $table_headings : explode(',', str_replace(' ','', $sortable_columns));
        }
//        dd($sortable_columns);

        // Ensure each row in $data has a unique ID
        if (!in_array('id', $all_table_headings)){
            foreach ($data as &$row){
                $row['id'] = uniqid();
            }
        }

        if(!empty($groupby) && in_array($groupby, $table_headings)) {
            $can_group = true;
            $unique_group_headings = array_unique(array_column($data, $groupby));
        }

        // build action icons
        foreach ($action_icons as $action) {
            $action_array = explode('|',$action);
            $temp_actions_arr = [];
            foreach($action_array as $this_action){
                $action_str_to_arr = explode(':', $this_action);
                $temp_actions_arr[trim($action_str_to_arr[0])] = trim($action_str_to_arr[1]);
            }
            $icons_array[] = $temp_actions_arr;
        }

        if(!function_exists('build_click')){
            function build_click($click, $row_data){
                return preg_replace_callback('/{\w+}/', function ($matches) use ($row_data) {
                    foreach($matches as $match) {
                        return $row_data[str_replace('}', '', str_replace('{', '', $match))];
                    }
                }, $click);
            }
        }

        if(!function_exists('pagination_row')){
            function pagination_row($row_number, $page_size=25, $default_page=1): string
            {
                $row_id =  uniqid();
                $row_page = ($row_number < $page_size) ? 1 : ceil($row_number/$page_size);
                return sprintf("data-id=%s data-page=%s class=%s", $row_id, $row_page,
                ($row_page != $default_page ? 'hidden' : ''));
            }
        }
    }
?>

<script>
    let tableData_<?php echo e(str_replace('-','_', $name)); ?> = <?php echo json_encode($data); ?>;
</script>
<div class="<?php if($has_border && !$celled): ?> border border-gray-200/70 dark:border-dark-700/60 <?php endif; ?> border-collapse max-w-full">
    <div class="w-full">
        <?php if($searchable): ?>
            <div class="bw-table-filter-bar">
                <?php if (isset($component)) { $__componentOriginal399ab5ed63addab89395df8c37031002 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal399ab5ed63addab89395df8c37031002 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.input','data' => ['name' => 'bw-search-'.e($name).'','placeholder' => ''.e($search_placeholder).'','onInput' => 'filterTableDebounced(this.value, \'table.'.e($name).'\', \''.e($search_field).'\', '.e($search_debounce).', '.e($search_min_length).', tableData_'.e(str_replace('-','_', $name)).')();','addClearing' => 'false','class' => '!mb-0 focus:!border-slate-300 !pl-9 !py-3','clearable' => 'true','prefixIsIcon' => 'true','prefix' => 'magnifying-glass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bw-search-'.e($name).'','placeholder' => ''.e($search_placeholder).'','onInput' => 'filterTableDebounced(this.value, \'table.'.e($name).'\', \''.e($search_field).'\', '.e($search_debounce).', '.e($search_min_length).', tableData_'.e(str_replace('-','_', $name)).')();','add_clearing' => 'false','class' => '!mb-0 focus:!border-slate-300 !pl-9 !py-3','clearable' => 'true','prefix_is_icon' => 'true','prefix' => 'magnifying-glass']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $attributes = $__attributesOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__attributesOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $component = $__componentOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__componentOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
        <table class="bw-table w-full <?php echo e($name); ?> <?php if($has_shadow): ?> drop-shadow shadow shadow-gray-200/70 dark:shadow-md dark:shadow-dark-950/20 <?php endif; ?>
            <?php if($divided): ?> divided <?php if($divider=='thin'): ?> thin <?php endif; ?> <?php endif; ?>  <?php if($striped): ?> striped <?php endif; ?>  <?php if($celled): ?> celled <?php endif; ?>
            <?php if($hover_effect): ?> with-hover-effect <?php endif; ?> <?php if($compact): ?> compact <?php endif; ?> <?php if($uppercasing): ?> uppercase-headers <?php endif; ?>
            <?php if($sortable): ?> sortable <?php endif; ?> <?php if($paginated): ?> paginated <?php endif; ?>
            <?php if($selectable): ?> selectable <?php endif; ?> <?php if($checkable): ?> checkable <?php endif; ?> <?php if($transparent): ?> transparent <?php endif; ?>"
               <?php if($paginated): ?> data-current-page="<?php echo e($default_page); ?>" <?php endif; ?>>
            <?php if(is_null($data) || $layout == 'custom'): ?>
                <?php if(!empty($header)): ?>
                    <thead>
                    <tr><?php echo e($header); ?></tr>
                    </thead>
                <?php endif; ?>
                <tbody><?php echo e($slot); ?></tbody>
            <?php else: ?>
                <thead>
                <tr>
                    <?php
                        // if there are no records, build the headings with $column_headings if the array exists
                        $table_headings = ($total_records>0) ? $table_headings : (($column_aliases) ?? []);
                        // when grouping rows, remove the heading for the column being grouped by
                        if($can_group) {
                            unset($table_headings[array_search($groupby, $table_headings)]);
                        }
                    ?>
                    <?php if($show_row_numbers): ?>
                        <th>#</th>
                    <?php endif; ?>
                    <?php $__currentLoopData = $table_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(empty($exclude_columns) || !in_array($th, $exclude_columns)): ?>
                            <?php
                                // get positions/indices of the fields to be displayed
                                // use these indices to directly target data to display from $data
                                $indices[] = $loop->index;
                            ?>
                            <th <?php if($sortable && in_array($th, $sortable_columns)): ?>
                                    class="cursor-pointer"
                                data-sort-dir="no-sort"
                                data-can-sort="true"
                                data-column-index="<?php echo e(count($indices)-1); ?>"
                                onclick="sortTableByColumn(this, '<?php echo e($name); ?>')" <?php endif; ?>>
                                <span class="peer cursor-pointer"><?php echo e(str_replace('_', ' ', $column_aliases[$th] ?? $th )); ?></span>
                                <?php if($sortable && in_array($th, $sortable_columns)): ?>
                                    <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'funnel','class' => '!size-3 opacity-40 peer-hover:opacity-80 no-sort']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'funnel','class' => '!size-3 opacity-40 peer-hover:opacity-80 no-sort']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'arrow-long-up','class' => '!size-3 opacity-60 peer-hover:opacity-90 sort-asc hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-long-up','class' => '!size-3 opacity-60 peer-hover:opacity-90 sort-asc hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'arrow-long-down','class' => '!size-3 opacity-60 peer-hover:opacity-90 sort-desc hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-long-down','class' => '!size-3 opacity-60 peer-hover:opacity-90 sort-desc hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </th>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($action_icons)): ?>
                        <th class="!text-right"><?php echo e($actions_title); ?></th>
                    <?php endif; ?>
                </tr>
                </thead>
                <?php if($total_records > 0 && $layout == 'auto'): ?>
                    <tbody>
                    <?php if($can_group): ?>
                        <?php $__currentLoopData = $unique_group_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="group-heading" colspan="<?php echo e(count($table_headings)); ?>"><?php echo e($group_heading); ?></td>
                            </tr>
                            <?php
                                $grouped_data = array_filter($data, function ($item) use ($group_heading, $groupby) {
                                    return $item[$groupby] === $group_heading;
                                });
                            ?>
                            <?php $__currentLoopData = $grouped_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $row_id =  $row['id']; ?>
                                <tr data-id="<?php echo e($row_id); ?>">
                                    <?php $__currentLoopData = $table_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($th !== $groupby): ?>
                                            <td data-row-id="<?php echo e($row_id); ?>"
                                                data-column="<?php echo e($th); ?>"><?php echo $row[$th]; ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if (isset($component)) { $__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table-icons','data' => ['iconsArray' => $icons_array,'row' => $row]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::table-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icons_array' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icons_array),'row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323)): ?>
<?php $attributes = $__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323; ?>
<?php unset($__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323)): ?>
<?php $component = $__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323; ?>
<?php unset($__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323); ?>
<?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $row_id =  $row['id'];
                                $row_page = (!$paginated || $loop->iteration < $page_size) ? 1 : ceil($loop->iteration/$page_size);
                            ?>
                            <?php if(!empty($limit) && $loop->iteration > $limit): ?>
                                <?php break; ?>
                            <?php endif; ?>
                            <tr data-id="<?php echo e($row_id); ?>" data-page="<?php echo e($row_page); ?>"
                                <?php if($paginated && $row_page != $default_page): ?>class="hidden" <?php endif; ?>>
                                <?php if($show_row_numbers): ?>
                                    <td><?php echo e($loop->iteration); ?></td>
                                <?php endif; ?>
                                <?php $__currentLoopData = $table_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($loop->index, $indices)): ?>
                                        <td data-row-id="<?php echo e($row_id); ?>"
                                            data-column="<?php echo e($th); ?>"><?php echo $row[$th]; ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table-icons','data' => ['iconsArray' => $icons_array,'row' => $row]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::table-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icons_array' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icons_array),'row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323)): ?>
<?php $attributes = $__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323; ?>
<?php unset($__attributesOriginalf42bd1558ff554c8c89fcdbcbdcf3323); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323)): ?>
<?php $component = $__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323; ?>
<?php unset($__componentOriginalf42bd1558ff554c8c89fcdbcbdcf3323); ?>
<?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php echo e(count($table_headings)); ?>" class="text-center">
                                <?php if($message_as_empty_state): ?>
                                    <?php if (isset($component)) { $__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.empty-state','data' => ['message' => $no_data_message,'buttonLabel' => $button_label,'onclick' => $onclick,'image' => $image,'showImage' => $show_image,'heading' => $heading]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($no_data_message),'button_label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($button_label),'onclick' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($onclick),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($image),'show_image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_image),'heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heading)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b)): ?>
<?php $attributes = $__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b; ?>
<?php unset($__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b)): ?>
<?php $component = $__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b; ?>
<?php unset($__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b); ?>
<?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($no_data_message); ?>

                                <?php endif; ?>
                                <script>
                                    changeCss('.<?php echo e($name); ?>', 'with-hover-effect', 'remove');
                                    changeCss('.<?php echo e($name); ?>', 'has-no-data');
                                </script>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                <?php endif; ?>
        </table>
        <?php if($paginated && !empty($total_records)): ?>
            <?php if (isset($component)) { $__componentOriginal7f90a3c8198951b967b933a73a856677 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f90a3c8198951b967b933a73a856677 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.pagination','data' => ['style' => $pagination_style,'totalRecords' => $total_records,'pageSize' => $page_size,'showTotal' => $show_total,'showTotalPages' => $show_total_pages,'showPageNumber' => $show_page_number,'label' => $total_label,'table' => $name,'defaultPage' => $default_page]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pagination_style),'total_records' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($total_records),'page_size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page_size),'show_total' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_total),'show_total_pages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_total_pages),'show_page_number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_page_number),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($total_label),'table' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name),'default_page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($default_page)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f90a3c8198951b967b933a73a856677)): ?>
<?php $attributes = $__attributesOriginal7f90a3c8198951b967b933a73a856677; ?>
<?php unset($__attributesOriginal7f90a3c8198951b967b933a73a856677); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f90a3c8198951b967b933a73a856677)): ?>
<?php $component = $__componentOriginal7f90a3c8198951b967b933a73a856677; ?>
<?php unset($__componentOriginal7f90a3c8198951b967b933a73a856677); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php if($selectable): ?>
    <?php if (! $__env->hasRenderedOnce('ab0ccfa8-0c71-4c9f-b9c5-c87d9b27cc92')): $__env->markAsRenderedOnce('ab0ccfa8-0c71-4c9f-b9c5-c87d9b27cc92'); ?>
        <script>
            const addRemoveRowValue = (value, name) => {
                const input = domEl(`input[type="hidden"][name="${name}"]`);
                const table = domEl(`.bw-table.${name}.selectable`);
                const checkAllBox = table.querySelector('th:first-child input[type="checkbox"]');
                const partiallyCheckedBox = table.querySelector('th:first-child .check-icon');
                const totalRows = table.getAttribute('data-total-rows') * 1;
                let totalChecked = table.getAttribute('data-total-checked') * 1;
                if (value) {
                    if (input.value.includes(value)) { // remove
                        const keyword = `(,?)${value}`;
                        input.value = input.value.replace(input.value.match(keyword)[0], '');
                        totalChecked--;
                    } else { // add
                        input.value += `,${value}`;
                        totalChecked++;
                    }
                    table.setAttribute('data-total-checked', `${totalChecked}`);
                    if (totalChecked > 0 && totalChecked < totalRows) {
                        hide(checkAllBox, true);
                        unhide(partiallyCheckedBox, true);
                        if (!partiallyCheckedBox.getAttribute('onclick')) {
                            partiallyCheckedBox.setAttribute('onclick', `checkAllFromPartiallyChecked('${name}')`);
                        }
                    } else {
                        unhide(checkAllBox, true);
                        hide(partiallyCheckedBox, true);
                        checkAllBox.checked = (totalChecked === totalRows);
                    }
                    stripComma(input);
                }
            }

            const checkAllFromPartiallyChecked = (name) => {
                const table = domEl(`.bw-table.${name}.selectable`);
                const checkAllBox = table.querySelector('th:first-child input[type="checkbox"]')
                checkAllBox.checked = true;
                toggleAll(checkAllBox, `.bw-table.${name}`);
            }
        </script>
    <?php endif; ?>
    <script>
        domEls('.bw-table.<?php echo e($name); ?>.selectable tr').forEach((el) => {
            el.addEventListener('click', (e) => {
                el.classList.toggle('selected');
                let id = el.getAttribute('data-id');
                let checkbox = el.querySelector('td:first-child input[type="checkbox"]');
                if (checkbox) checkbox.checked = el.classList.contains('selected');
                addRemoveRowValue(id, '<?php echo e($name); ?>');
            });
        });
    </script>
    <input type="hidden" name="<?php echo e($name); ?>" class="<?php echo e($name); ?>"/>
<?php endif; ?>

<?php if($checkable): ?>
    <?php if (! $__env->hasRenderedOnce('cebe336d-9d4f-4990-8693-ad024dec41fb')): $__env->markAsRenderedOnce('cebe336d-9d4f-4990-8693-ad024dec41fb'); ?>
        <div class="hidden size-0 checkbox-template">
            <?php if (isset($component)) { $__componentOriginal701009bc86ef91af6041f0e4d6588e8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.checkbox','data' => ['class' => '!size-5 !mr-0 rounded-md','labelCss' => 'mr-0','addClearing' => 'false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!size-5 !mr-0 rounded-md','label_css' => 'mr-0','add_clearing' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $attributes = $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $component = $__componentOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
        </div>
        <div class="hidden size-0 partial-check-template">
            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'minus','type' => 'solid','class' => 'hidden stroke-2 rounded-md bg-primary-500 text-white check-icon !size-5 !mb-1 !mt-[4px] !-ml-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'minus','type' => 'solid','class' => 'hidden stroke-2 rounded-md bg-primary-500 text-white check-icon !size-5 !mb-1 !mt-[4px] !-ml-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
        </div>
        <script>
            const addCheckboxesToTable = (el) => {
                let table = domEl(el);
                let checkboxHtml = domEl('.checkbox-template').innerHTML;
                let partialCheckHtml = domEl('.partial-check-template').innerHTML;

                for (let row of table.rows) {
                    let cellTag = (row.parentElement.tagName.toLowerCase() === 'thead') ? 'th' : 'td';
                    let checkboxCell = document.createElement(cellTag);
                    checkboxCell.innerHTML = (cellTag === 'th') ?
                        checkboxHtml.replace('type="checkbox"', `type="checkbox" onclick="toggleAll(this,'${el}')"`) + partialCheckHtml :
                        checkboxHtml;
                    checkboxCell.setAttribute('class', '!size-0 !pr-0');
                    row.insertBefore(checkboxCell, row.firstChild);
                }
                table.setAttribute('data-total-rows', (table.rows.length - 1)); // minus heading
                table.setAttribute('data-total-checked', 0);
            }

            const toggleAll = (srcEl, table) => {
                domEls(`${table}.selectable tr`).forEach((el) => {
                    const checkbox = el.querySelector('td:first-child input[type="checkbox"]');
                    if (checkbox) {
                        // to properly take advantage of the logic for adding and removing IDs
                        // already defined in addRemoveRowValue(), simply simulate a click of the checkbox
                        if (srcEl.checked && !checkbox.checked || (!srcEl.checked && checkbox.checked)) el.click();
                    }
                });
            }

            const checkSelected = (table, selectedValue) => {
                let selectedValues = selectedValue.split(',');
                domEls(`${table}.selectable tr`).forEach((el) => {
                    const thisValue = el.getAttribute('data-id');
                    if (selectedValues.includes(thisValue)) {
                        el.click();
                    }
                });
            }
        </script>
    <?php endif; ?>
    <script>
        addCheckboxesToTable('.bw-table.<?php echo e($name); ?>');
        // select rows in selected_value
        <?php if(!empty($selected_value)): ?> checkSelected('.bw-table.<?php echo e($name); ?>', '<?php echo e($selected_value); ?>') <?php endif; ?>
    </script>
<?php endif; ?>
<?php if($sortable): ?>
    <?php if (! $__env->hasRenderedOnce('0d464c7b-7865-4caa-9f2f-469747e9b96a')): $__env->markAsRenderedOnce('0d464c7b-7865-4caa-9f2f-469747e9b96a'); ?>
        <script>
            const originalTableOrder = new Map();

            // Save the initial order of all tables when the page loads
            window.onload = () => {
                document.querySelectorAll("table.sortable").forEach(table => {
                    const tbody = table.tBodies[0];
                    const rows = Array.from(tbody.rows);
                    originalTableOrder.set(table, rows); // Store original rows for this table
                });
            };

            const sortTableByColumn = (el, table) => {
                let sortColumnIndex = el.getAttribute('data-column-index');
                let sortDirection = el.getAttribute('data-sort-dir') || 'no-sort';
                let sortTable = domEl(`.${table}`);
                const tbody = sortTable.tBodies[0];
                let currentPage = String(sortTable.getAttribute('data-current-page') || 1);

                changeColumnSortIcon(sortColumnIndex, table, sortDirection);

                sortDirection = (sortDirection === "no-sort") ? "asc" : ((sortDirection === "asc") ? "desc" : "no-sort");
                let sortColumn = domEl(`.${table} th[data-column-index="${sortColumnIndex}"]`);
                sortColumn.setAttribute('data-sort-dir', sortDirection);

                if (sortDirection === "no-sort") {
                    resetToOriginalOrder(sortTable, tbody, currentPage);
                } else {
                    const rows = Array.from(tbody.rows).filter(row => (row.getAttribute('data-page') === currentPage));
                    document.body.appendChild(tbody);

                    rows.forEach(row => {
                        row.sortKey = row.cells[sortColumnIndex].innerText.toLowerCase();
                    });

                    rows.sort((a, b) => {
                        const result = a.sortKey.localeCompare(b.sortKey);
                        return sortDirection === "asc" ? result : -result;
                    });

                    rows.forEach(row => tbody.appendChild(row));
                    sortTable.appendChild(tbody);
                }
            }

            const changeColumnSortIcon = (column, table, direction) => {
                resetColumnSortIcons(table);
                if (direction === 'no-sort') {
                    hide(`.${table} th[data-column-index="${column}"] svg.no-sort`);
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-desc`);
                    unhide(`.${table} th[data-column-index="${column}"] svg.sort-asc`);
                }
                if (direction === 'asc') {
                    hide(`.${table} th[data-column-index="${column}"] svg.no-sort`);
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-asc`);
                    unhide(`.${table} th[data-column-index="${column}"] svg.sort-desc`);
                }
                if (direction === 'desc') {
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-asc`);
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-desc`);
                    unhide(`.${table} th[data-column-index="${column}"] svg.no-sort`);
                }
            }

            const resetColumnSortIcons = (table) => {
                domEls(`.${table} th[data-can-sort="true"]`).forEach((el) => {
                    let column = el.getAttribute('data-column-index');
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-desc`);
                    hide(`.${table} th[data-column-index="${column}"] svg.sort-asc`);
                    unhide(`.${table} th[data-column-index="${column}"] svg.no-sort`);
                    el.setAttribute('data-sort-dir', 'no-sort');
                });
            }

            function resetToOriginalOrder(table, tbody, currentPage) {
                const originalRows = originalTableOrder.get(table);
                const currentPageRows = originalRows.filter(row => (row.getAttribute('data-page') === currentPage));
                currentPageRows.forEach(row => tbody.appendChild(row));
            }
        </script>
    <?php endif; ?>
<?php endif; ?><?php /**PATH C:\laragon\www\sikuat\vendor\mkocansey\bladewind\src/../resources/views/components/table.blade.php ENDPATH**/ ?>