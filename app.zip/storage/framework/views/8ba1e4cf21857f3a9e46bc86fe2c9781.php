<!DOCTYPE html>
<html lang="en">
<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781d22988f835a9692410092c1d21cd6 = $attributes; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $attributes = $__attributesOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__attributesOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<body class="bg-gray-100">
  <div class="flex">
    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6">

      <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
      <!-- Stats -->
      <div class="grid grid-cols-4 gap-6 mb-6">
        <div class="bg-white shadow p-6 rounded-lg">
          <h3 class="text-gray-500">Total Views</h3>
          <p class="text-2xl font-bold">$3.456K</p>
          <span class="text-green-500 text-sm">+0.43%</span>
        </div>
        <div class="bg-white shadow p-6 rounded-lg">
          <h3 class="text-gray-500">Total Profit</h3>
          <p class="text-2xl font-bold">$45.2K</p>
          <span class="text-green-500 text-sm">+4.35%</span>
        </div>
        <div class="bg-white shadow p-6 rounded-lg">
          <h3 class="text-gray-500">Total Product</h3>
          <p class="text-2xl font-bold">2.450</p>
          <span class="text-green-500 text-sm">+2.59%</span>
        </div>
        <div class="bg-white shadow p-6 rounded-lg">
          <h3 class="text-gray-500">Total Users</h3>
          <p class="text-2xl font-bold">3.456</p>
          <span class="text-red-500 text-sm">-0.95%</span>
        </div>
      </div>

      <!-- Charts -->
      <div class="grid grid-cols-2 gap-6">
        <div class="bg-white shadow p-6 rounded-lg">
        <?php if (isset($component)) { $__componentOriginal25f1fcadeccc75098fc7111d3ba6ebfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25f1fcadeccc75098fc7111d3ba6ebfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.card','data' => ['title' => 'User`s Age Ratio']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'User`s Age Ratio']); ?>

          <?php if (isset($component)) { $__componentOriginal7666d208a986bb7934052694fe636d83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7666d208a986bb7934052694fe636d83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.horizontal-line-graph','data' => ['label' => 'Above 60: ','percentage' => '33','color' => 'cyan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::horizontal-line-graph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Above 60: ','percentage' => '33','color' => 'cyan']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $attributes = $__attributesOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__attributesOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $component = $__componentOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__componentOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
  
          <?php if (isset($component)) { $__componentOriginal7666d208a986bb7934052694fe636d83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7666d208a986bb7934052694fe636d83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.horizontal-line-graph','data' => ['label' => 'Between 40 - 60: ','percentage' => '43','color' => 'purple','class' => 'py-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::horizontal-line-graph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Between 40 - 60: ','percentage' => '43','color' => 'purple','class' => 'py-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $attributes = $__attributesOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__attributesOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $component = $__componentOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__componentOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
  
          <?php if (isset($component)) { $__componentOriginal7666d208a986bb7934052694fe636d83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7666d208a986bb7934052694fe636d83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.horizontal-line-graph','data' => ['label' => 'Under 40: ','percentage' => '24','color' => 'gray']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::horizontal-line-graph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Under 40: ','percentage' => '24','color' => 'gray']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $attributes = $__attributesOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__attributesOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7666d208a986bb7934052694fe636d83)): ?>
<?php $component = $__componentOriginal7666d208a986bb7934052694fe636d83; ?>
<?php unset($__componentOriginal7666d208a986bb7934052694fe636d83); ?>
<?php endif; ?>
  
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25f1fcadeccc75098fc7111d3ba6ebfe)): ?>
<?php $attributes = $__attributesOriginal25f1fcadeccc75098fc7111d3ba6ebfe; ?>
<?php unset($__attributesOriginal25f1fcadeccc75098fc7111d3ba6ebfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25f1fcadeccc75098fc7111d3ba6ebfe)): ?>
<?php $component = $__componentOriginal25f1fcadeccc75098fc7111d3ba6ebfe; ?>
<?php unset($__componentOriginal25f1fcadeccc75098fc7111d3ba6ebfe); ?>
<?php endif; ?>
    </div>
  
        <div class="bg-white shadow p-6 rounded-lg flex justify-between">
          <?php if (isset($component)) { $__componentOriginal7e514ed964fffdaa8b77865ff002148d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e514ed964fffdaa8b77865ff002148d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.progress-circle','data' => ['percentage' => '58','showLabel' => 'true','showPercent' => 'true','size' => 'big']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::progress-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['percentage' => '58','show_label' => 'true','show_percent' => 'true','size' => 'big']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $attributes = $__attributesOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $component = $__componentOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__componentOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal7e514ed964fffdaa8b77865ff002148d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e514ed964fffdaa8b77865ff002148d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.progress-circle','data' => ['percentage' => '50','showLabel' => 'true','showPercent' => 'true','size' => 'big','color' => 'cyan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::progress-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['percentage' => '50','show_label' => 'true','show_percent' => 'true','size' => 'big','color' => 'cyan']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $attributes = $__attributesOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $component = $__componentOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__componentOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal7e514ed964fffdaa8b77865ff002148d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e514ed964fffdaa8b77865ff002148d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.progress-circle','data' => ['percentage' => '48','showLabel' => 'true','showPercent' => 'true','size' => 'big','color' => 'yellow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::progress-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['percentage' => '48','show_label' => 'true','show_percent' => 'true','size' => 'big','color' => 'yellow']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $attributes = $__attributesOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__attributesOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e514ed964fffdaa8b77865ff002148d)): ?>
<?php $component = $__componentOriginal7e514ed964fffdaa8b77865ff002148d; ?>
<?php unset($__componentOriginal7e514ed964fffdaa8b77865ff002148d); ?>
<?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sikuat\resources\views/admin.blade.php ENDPATH**/ ?>