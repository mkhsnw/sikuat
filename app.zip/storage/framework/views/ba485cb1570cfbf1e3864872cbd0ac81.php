<!DOCTYPE html>
<html lang="en">
<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781d22988f835a9692410092c1d21cd6 = $attributes; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $attributes = $__attributesOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__attributesOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<body class="bg-gray-100">
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
    
    <!-- Main Content -->
    <main class="flex-1 p-6">
      <!-- Navbar -->
      <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

      <!-- Grid Layout -->
      <div class="grid grid-cols-2 gap-6">
        <!-- Blog Section -->
        <div class="bg-white p-6 rounded-lg shadow flex flex-col h-full">
          <div class="overflow-y-auto flex-1 max-h-[50rem]">
            <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
          </div>
        </div>

        <!-- Profile Section -->
        <div class="bg-white p-6 rounded-lg shadow flex flex-col h-full">
          <div class="bg-gray-200 rounded-lg shadow-lg p-4 flex-1 max-h-[50rem] overflow-y-auto">
            <!-- Profile Section -->
            <div class="flex items-center mb-4">
              <div class="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                <span class="text-sm font-semibold">Profile</span>
              </div>
              <div class="ml-4">
                <h2 class="text-lg font-bold">Account One</h2>
              </div>
            </div>

            <!-- Thumbnail -->
            <div class="bg-white border border-gray-300 rounded-lg h-32 flex items-center justify-center mb-4">
              <span class="font-bold text-gray-500">Thumbnail</span>
            </div>

            <!-- Text Content -->
            <div class="text-gray-700 text-sm mb-4">
              <p>
                This is the first tweet in the thread. You can write longer text here
                to simulate how tweets are presented. This is the first tweet in the
                thread. You can write longer text here to simulate how tweets are
                presented. This is the first tweet in the thread.
              </p>
              <p>
                Add more content here to test scrolling. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.
              </p>
            </div>

            <!-- Buttons -->
            <div class="flex justify-end space-x-4">
              <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400">
                Revisi
              </button>
              <button class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                Accept
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sikuat\resources\views/admin_detail_artikel.blade.php ENDPATH**/ ?>