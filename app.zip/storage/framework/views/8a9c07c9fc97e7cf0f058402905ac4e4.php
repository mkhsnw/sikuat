<aside class="w-64 bg-gray-800 text-white h-screen">
    <div class="p-6">
      <h1 class="text-2xl font-bold">Sikuat</h1>
    </div>
    <nav>
      <ul>
        <li class="px-6 py-3 hover:bg-gray-700"><a href="/admin/dashboard">Dashboard</a></li>
        <li class="px-6 py-3 hover:bg-gray-700"><a href="/admin/challange">Challange</a></li>
        <li class="px-6 py-3 hover:bg-gray-700"><a href="/admin/article">Article</a></li>
        <li class="px-6 py-3 hover:bg-gray-700"><a href="/admin/detail_article">Review Article</a></li>
      </ul>
    </nav>
  </aside><?php /**PATH C:\laragon\www\sikuat\resources\views/components/sidebar.blade.php ENDPATH**/ ?>