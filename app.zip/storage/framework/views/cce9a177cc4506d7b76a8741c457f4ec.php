<?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<div class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
	<div class="max-w-6xl w-full">
        <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
</div>
</div>
<?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\sikuat\resources\views/article.blade.php ENDPATH**/ ?>