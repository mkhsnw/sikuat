<!DOCTYPE html>
<html lang="en">
<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781d22988f835a9692410092c1d21cd6 = $attributes; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $attributes = $__attributesOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__attributesOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<body class="bg-gray-100">
  <div class="flex">
    <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
    <main class="flex-1 p-6">
      <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
      <div class="bg-white shadow p-6 rounded-lg">
        <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['showFocusRing' => 'false','color' => 'green']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['show-focus-ring' => 'false','color' => 'green']); ?>tambah Challange <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table','data' => ['divider' => 'thin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['divider' => 'thin']); ?>
           <?php $__env->slot('header', null, []); ?> 
            <th>NO</th>
            <th>Nama Challange</th>
            <th>Kategori</th>
            <th>Tanggal Dibuat</th>
            <th>Point</th>
            <th>Aksi</th>
           <?php $__env->endSlot(); ?>

          <tr>
            <td>1</td>
            <td>Push Up</td>
            <td>Angkat Beban</td>
            <td>1990-10-20</td>
            <td>500</td>
            <td>
              <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['onclick' => 'showModal(\'custom-actions\')','color' => 'red']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'showModal(\'custom-actions\')','color' => 'red']); ?>
                Hapus
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','okButtonAction' => 'alert(\'as you wish\')','cancelButtonAction' => 'alert(\'good choice\')','closeAfterAction' => 'true','name' => 'custom-actions','okButtonLabel' => 'Yes, delete','cancelButtonLabel' => 'don\'t delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','ok_button_action' => 'alert(\'as you wish\')','cancel_button_action' => 'alert(\'good choice\')','close_after_action' => 'true','name' => 'custom-actions','ok_button_label' => 'Yes, delete','cancel_button_label' => 'don\'t delete']); ?>
                Are you sure you want to delete this user? This action cannot be undone.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
            </td>
          </tr>

          <tr>
            <td>1</td>
            <td>Push Up</td>
            <td>Angkat Beban</td>
            <td>1990-10-20</td>
            <td>500</td>
            <td>
            <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['onclick' => 'showModal(\'custom-actions\')','color' => 'red']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'showModal(\'custom-actions\')','color' => 'red']); ?>
              Hapus
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
          
          <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','okButtonAction' => 'alert(\'as you wish\')','cancelButtonAction' => 'alert(\'good choice\')','closeAfterAction' => 'true','name' => 'custom-actions','okButtonLabel' => 'Yes, delete','cancelButtonLabel' => 'don\'t delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','ok_button_action' => 'alert(\'as you wish\')','cancel_button_action' => 'alert(\'good choice\')','close_after_action' => 'true','name' => 'custom-actions','ok_button_label' => 'Yes, delete','cancel_button_label' => 'don\'t delete']); ?>
              Are you sure you want to delete this user? This action cannot be undone.
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
            </td>
          </tr>

          <tr>
            <td>1</td>
            <td>Push Up</td>
            <td>Angkat Beban</td>
            <td>1990-10-20</td>
            <td>500</td>
            <td>
              <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['onclick' => 'showModal(\'custom-actions\')','color' => 'red']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'showModal(\'custom-actions\')','color' => 'red']); ?>
                Hapus
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','okButtonAction' => 'alert(\'as you wish\')','cancelButtonAction' => 'alert(\'good choice\')','closeAfterAction' => 'true','name' => 'custom-actions','okButtonLabel' => 'Yes, delete','cancelButtonLabel' => 'don\'t delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'big','type' => 'warning','title' => 'Confirm User Deletion','ok_button_action' => 'alert(\'as you wish\')','cancel_button_action' => 'alert(\'good choice\')','close_after_action' => 'true','name' => 'custom-actions','ok_button_label' => 'Yes, delete','cancel_button_label' => 'don\'t delete']); ?>
                Are you sure you want to delete this user? This action cannot be undone.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
            </td>
          </tr>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $attributes = $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $component = $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
      </div>
    </main>
  </div>
  
</body>
</html><?php /**PATH C:\laragon\www\sikuat\resources\views/admin_challange.blade.php ENDPATH**/ ?>