<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP code is: <strong><?php echo e($token); ?></strong></p>
</body>
</html>
<?php /**PATH C:\laragon\www\sikuat\resources\views/emails/token.blade.php ENDPATH**/ ?>