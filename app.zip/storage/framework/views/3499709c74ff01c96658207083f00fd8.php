<header class="flex justify-between items-center mb-6">
    <input
      type="text"
      placeholder="Search..."
      class="border border-gray-300 rounded-lg p-2 w-1/3"
    />
    <div class="flex items-center space-x-4">
      <button class="bg-gray-200 rounded-full p-2">
        <?php if (isset($component)) { $__componentOriginalb0ea2143cc3fb05f3a225189451ce926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb0ea2143cc3fb05f3a225189451ce926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.bell','data' => ['animateDot' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::bell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['animate_dot' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb0ea2143cc3fb05f3a225189451ce926)): ?>
<?php $attributes = $__attributesOriginalb0ea2143cc3fb05f3a225189451ce926; ?>
<?php unset($__attributesOriginalb0ea2143cc3fb05f3a225189451ce926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb0ea2143cc3fb05f3a225189451ce926)): ?>
<?php $component = $__componentOriginalb0ea2143cc3fb05f3a225189451ce926; ?>
<?php unset($__componentOriginalb0ea2143cc3fb05f3a225189451ce926); ?>
<?php endif; ?>
      </button>
      <?php if (isset($component)) { $__componentOriginala0d286332d7c052588567c9c0851b512 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0d286332d7c052588567c9c0851b512 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('trigger', null, []); ?> 
        <div class="flex space-x-2 items-center rounded-md">
            <div class="grow">
                <?php if (isset($component)) { $__componentOriginal0ad07d55369c3f142811e8f2e87d048d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.avatar','data' => ['image' => '/assets/...jpg','size' => 'medium']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/assets/...jpg','size' => 'medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $attributes = $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $component = $__componentOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
            </div>
            <div>
                <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'chevron-down','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => ['header' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'true']); ?>
        <div class="grow">
            <div><strong>Jane A. Doe</strong></div>
            <div class="text-sm">@jane-the-coder</div>
            <div class="text-sm">jane@bladewindui.com</div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => ['hover' => 'false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hover' => 'false']); ?>
        <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['color' => '','radius' => 'small','size' => 'small','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => '','radius' => 'small','size' => 'small','class' => 'w-full']); ?>
            Sign Out
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $attributes = $__attributesOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__attributesOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $component = $__componentOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__componentOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
     
    </div>
  </header><?php /**PATH C:\laragon\www\sikuat\resources\views/components/navbar.blade.php ENDPATH**/ ?>