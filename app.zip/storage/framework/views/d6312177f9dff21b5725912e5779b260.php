<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>sikuat</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="//unpkg.com/alpinejs" defer></script>
    <link href="<?php echo e(asset('vendor/bladewind/css/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/bladewind/css/bladewind-ui.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('vendor/bladewind/js/helpers.js')); ?>"></script>
    
</head>
<body class="">
    <header class="header top-0 shadow-md flex items-center justify-between px-8 py-02 bg-test">
        <!-- logo -->
        <h1 class="w-3/12">
            <a href="" class="font-bold hover:text-accent duration-200 text-2xl">siKuat</a>
              
        </h1>
    
        <!-- navigation -->
        <nav class="nav font-semibold text-lg ">
            <ul class="flex items-center">
                <li class="p-4 border-b-2 border-accent border-opacity-0 hover:border-opacity-100 hover:text-accent duration-200 cursor-pointer active">
                  <a href="/article">Article</a>
                </li>
                <li class="p-4 border-b-2 border-accent border-opacity-0 hover:border-opacity-100 hover:text-accent duration-200 cursor-pointer">
                  <a href="/">Challange</a>
                </li>
                <li class="p-4 border-b-2 border-accent border-opacity-0 hover:border-opacity-100 hover:text-accent duration-200 cursor-pointer">
                  <a href="/thread">Thread</a>
                </li>
            </ul>
        </nav>
    
        <!-- buttons --->
        <div class="w-3/12 flex justify-end">
            <?php if (isset($component)) { $__componentOriginala0d286332d7c052588567c9c0851b512 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0d286332d7c052588567c9c0851b512 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <div class="flex space-x-2 items-center shadow px-4 rounded-md">
                    <div class="grow">
                        <?php if (isset($component)) { $__componentOriginal0ad07d55369c3f142811e8f2e87d048d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.avatar','data' => ['image' => '/assets/...png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/assets/...png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $attributes = $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $component = $__componentOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
                    </div>
                    <div>
                        <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'chevron-down','class' => '!h-4 !w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => '!h-4 !w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                    </div>
                </div>
             <?php $__env->endSlot(); ?>
            <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Deactivate my account
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $attributes = $__attributesOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__attributesOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $component = $__componentOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__componentOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
        </div>
    </header>
</body><?php /**PATH C:\laragon\www\sikuat\resources\views/components/header.blade.php ENDPATH**/ ?>