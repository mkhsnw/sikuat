<!DOCTYPE html>
<html lang="en">
<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781d22988f835a9692410092c1d21cd6 = $attributes; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $attributes = $__attributesOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__attributesOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<body class="bg-gray-100">
  <div class="flex">
    <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
    <main class="flex-1 p-6">
      <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

      <div class="bg-white shadow p-6 rounded-lg">
        <?php if (isset($component)) { $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table','data' => ['divider' => 'thin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['divider' => 'thin']); ?>
           <?php $__env->slot('header', null, []); ?> 
            <th>NO</th>
            <th>Nama Lengkap</th>
            <th>Username</th>
            <th>Tanggal Upload</th>
            <th>Email</th>
            <th>Aksi</th>
           <?php $__env->endSlot(); ?>

          <tr>
            <td>1</td>
            <td>Budiman</td>
            <td>Budi</td>
            <td>1990-10-20</td>
            <td>budi@me.com</td>
            <td>
              <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Lihat Detail
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
            </td>
          </tr>

          <tr>
            <td>1</td>
            <td>Budiman</td>
            <td>Budi</td>
            <td>1990-10-20</td>
            <td>budi@me.com</td>
            <td>
              <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Lihat Detail
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
            </td>
          </tr>

          <tr>
            <td>1</td>
            <td>Budiman</td>
            <td>Budi</td>
            <td>1990-10-20</td>
            <td>budi@me.com</td>
            <td>
              <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Lihat Detail
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
            </td>
          </tr>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $attributes = $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $component = $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
      </div>
    </main>
  </div>
  
</body>
</html><?php /**PATH C:\laragon\www\sikuat\resources\views/admin_article.blade.php ENDPATH**/ ?>