<x-header></x-header>
<div class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
	<div class="max-w-6xl w-full">
        <x-blog></x-blog>
        <x-blog></x-blog>
        <x-blog></x-blog>
</div>
</div>
<x-footer></x-footer>