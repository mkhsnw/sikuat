<x-header></x-header>

        <x-blog></x-blog>
        <x-blog></x-blog>
        <x-blog></x-blog>
        
<x-footer></x-footer>