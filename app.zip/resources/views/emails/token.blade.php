<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP code is: <strong>{{ $token }}</strong></p>
</body>
</html>
